SELECT
  id,
  version,
  created_at,
  created_by,
  name,
  description
FROM
  ver.V_VERSIONS
ORDER BY version ASC;